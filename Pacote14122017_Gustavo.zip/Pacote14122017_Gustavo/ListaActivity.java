package com.example.erick.paradacerta;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class ListaActivity extends AppCompatActivity {

    private ListView listaLinhas;


    private ArrayAdapter<String> itensAdaptador;
    private ArrayList<String> codigo;
    private ArrayList<String> nome;
    private ArrayList<String> idlinha;
    private ArrayList<String> resultado;
    static ArrayList<String> linhas;

    Button BtnMaps;
    Button BtnCadastro;

    SQLiteDatabase bancoDados;


    Button mBtnFind;
    EditText etPlace;
//segunda versao do menu -14/12/2017
private void ShowDialogMenu2(final Activity act, @DrawableRes int imagem, String titulo, String mensagem) {

    final CharSequence[] items = {"Qual a sua opção?","   Horários", "   Histórico", "   Linhas", "   Mapa", "   Perfil",
            "   Sair"};
    AlertDialog.Builder builder = new AlertDialog.Builder(ListaActivity.this);
    builder.setTitle(titulo)
            //.setMessage(mensagem)
            .setCancelable(true)
            .setIcon(imagem)
            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    //cancelar
                    dialog.dismiss();
                }
            });
    builder.setItems(items, new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int item) {

            if (items[item].equals("   Horários")) {
                Intent nextActivity = new Intent(getBaseContext(), ListaHorarioActivity.class);
                startActivity(nextActivity);

            } else if (items[item].equals("   Linhas")) {
                Intent nextActivity = new Intent(getBaseContext(), ListaActivity.class);
                startActivity(nextActivity);

            } else if (items[item].equals("   Histórico")) {
                //manutencao
                Intent nextActivity = new Intent(getBaseContext(), HistoricoActivity.class);
                startActivity(nextActivity);

            } else if (items[item].equals("   Mapa")) {
                Intent nextActivity = new Intent(getBaseContext(), MapsActivity.class);
                startActivity(nextActivity);
            } else if (items[item].equals("   Perfil")) {
                Intent nextActivity = new Intent(getBaseContext(), CadastroActivity.class);
                startActivity(nextActivity);
            } else if (items[item].equals("   Sair")) {
                dialog.dismiss();
                act.finish();
            }
        }
    });
    builder.show();
}
    ///Tentativa do menu-13/12/2017 Gustavo
    public void ShowDialogMenu(final Activity act, @DrawableRes int imagem, String titulo, String mensagem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(act);
        CharSequence[] opcoes = {"Sair", "Perfil", "Lista de Linhas"};
        final View view;
        builder.setTitle(titulo)
                .setMessage(mensagem)
                .setCancelable(true)
                .setIcon(imagem)
                /*.setPositiveButton("VOLTAR", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                        act.recreate();
                    }
            })*/.setNeutralButton("SAIR", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                act.finish();
            }
        }).setNegativeButton("Perfil", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent nextActivity = new Intent(getBaseContext(), CadastroActivity.class);
                startActivity(nextActivity);
                //finish();

            }
        }).setPositiveButton("Lista de Linhas", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent nextActivity = new Intent(getBaseContext(), ListaActivity.class);
                startActivity(nextActivity);
                //finish();
            }
        })


        ;

        builder.create().show();        // create and show the alert dialog

    }
    ///Tentativa do menu-13/12/2017 Gustavo --opcao no canto ao lado da pesquisa
    public void opcaoMenu(View view){

        if (view.getId() == R.id.btnMapa)
            startActivity(new Intent(this, MapsActivity.class));
        else if (view.getId() == R.id.btnMenu)
            ShowDialogMenu2(ListaActivity.this, R.drawable.ico_parada_certa_bus, "MENU", "Qual a sua opção?");

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
       /* BtnCadastro = (Button) findViewById(R.id.BtnCadastro);

        BtnCadastro.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(ListaActivity.this, CadastroActivity.class);
                startActivity(i);
            }
        });

        BtnMaps = (Button) findViewById(R.id.BtnMaps);

        BtnMaps.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(ListaActivity.this, MapsActivity.class);
                startActivity(i);
            }
        });*/

        //recebe o parametro do listaactivity e carrega a rota da linha
        Bundle bundle = getIntent().getExtras();
        String linhaid = null;
        linhaid = bundle.getString("idLinha");

        if(linhaid != null){
            Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
            intent.putExtra("idLinha", linhaid);
            startActivity(intent);
        }else {
            listaLinhas = (ListView) findViewById(R.id.listviewid);
            carregaLinhas();
        }

        // Getting reference to the find button
        mBtnFind = (Button) findViewById(R.id.btn_show);

        // Getting reference to EditText
        etPlace = (EditText) findViewById(R.id.et_place);

//         Setting click event listener for the find button
        mBtnFind.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Getting the place entered

                try {
                String location = etPlace.getText().toString();

                if(location==null || location.equals("")){
                    Toast.makeText(getBaseContext(), "Nenhum endereço preenchido", Toast.LENGTH_SHORT).show();
                    return;
                }

                bancoDados = openOrCreateDatabase("appbanco.sqlite", MODE_PRIVATE, null);

                Cursor cursor = bancoDados.rawQuery("SELECT distinct codigoNome FROM coordenadas where codigoNome like '%" + location +"%'", null);

                int indiceColunaNome = cursor.getColumnIndex("codigoNome");

                resultado = new ArrayList<String>();

                itensAdaptador = new ArrayAdapter<String>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1,
                        resultado);

                listaLinhas = (ListView) findViewById(R.id.listviewid);
                listaLinhas.setAdapter(itensAdaptador);

                cursor.moveToNext();
                while (cursor != null) {

                    resultado.add(cursor.getString(indiceColunaNome));

                    //Log.i("LogX","Código: " + cursor.getString(indiceColunaCodigo) + " Linha: " +cursor.getString(indiceColunaNome));
                    cursor.moveToNext();
                }
                listaLinhas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                     public void onItemClick(AdapterView<?> adapter, View view, int position, long id){
                                                    Intent intent = new Intent(ListaActivity.this, HistoricoActivity.class);
                                                    intent.putExtra("id",id);
                                                    startActivity(intent);
                                                }
                });
                } catch (Exception e) {
                e.printStackTrace();
            }
            }
        });

    }

    //Carrega a lista de linhas disponíveis, nela será possível escolher a linha necessária para carregar as paradas a seguir.
    private void carregaLinhas() {

        try {

            bancoDados = openOrCreateDatabase("appbanco.sqlite", MODE_PRIVATE, null);

            Cursor cursor = bancoDados.rawQuery("SELECT * FROM linhas", null);

            int indiceColunaCodigo = cursor.getColumnIndex("codigo");
            int indiceColunaNome = cursor.getColumnIndex("nome");
            int indiceColunaId = cursor.getColumnIndex("idlinha");

            codigo = new ArrayList<String>();
            nome = new ArrayList<String>();
            idlinha = new ArrayList<String>();
            resultado = new ArrayList<String>();

            itensAdaptador = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    resultado);

            listaLinhas.setAdapter(itensAdaptador);

            linhas = new ArrayList<>();
            linhas.add("linha");

            listaLinhas.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String linhaid = idlinha.get(position);
                    //Log.i("IDLinha", linhaid);
                    //carregaParadas(idlinha.get(position));

                    Intent intent = new Intent(getApplicationContext(), MapsRotaActivity.class);
                    intent.putExtra("idLinha", linhaid);
                    startActivity(intent);
                }
            });

            cursor.moveToFirst();
            while (cursor != null) {

                codigo.add(cursor.getString(indiceColunaCodigo));
                nome.add(cursor.getString(indiceColunaNome));
                idlinha.add(cursor.getString(indiceColunaId));
                resultado.add(cursor.getString(indiceColunaCodigo) + " " + cursor.getString(indiceColunaNome));

                //Log.i("LogX","Código: " + cursor.getString(indiceColunaCodigo) + " Linha: " +cursor.getString(indiceColunaNome));
                cursor.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
